<?php
/* Smarty version 3.1.40, created on 2022-07-01 12:51:13
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/noty_notifications.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62beedc1bc5f01_06722640',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bcc5f5f7c699dae04aa5fe73cb52c82484cdd2e6' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/noty_notifications.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62beedc1bc5f01_06722640 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 58 39" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Page-1" fill="none" fill-rule="evenodd"><g id="026---message-warning" fill-rule="nonzero"><path id="Shape" d="m58 6v18c0 3.3137085-2.6862915 6-6 6h-14.959c-.6524499.0001341-1.26382.3185094-1.638.853l-5.584 7.72c-.1871548.267134-.492829.4262065-.819.4262065s-.6318452-.1590725-.819-.4262065l-5.581-7.72c-.3747875-.5353595-.9874904-.8538455-1.641-.853h-14.959c-3.3137085 0-6-2.6862915-6-6v-18c0-3.3137085 2.6862915-6 6-6h46c3.3137085 0 6 2.6862915 6 6z" fill="#f0c419"/><circle id="Oval" cx="15" cy="15" fill="#3b97d3" r="10"/><g fill="#fff"><path id="Shape" d="m15 16c-.5522847 0-1-.4477153-1-1v-6c0-.55228475.4477153-1 1-1s1 .44771525 1 1v6c0 .5522847-.4477153 1-1 1z"/><path id="Shape" d="m15 22c-.5522847 0-1-.4477153-1-1v-2c0-.5522847.4477153-1 1-1s1 .4477153 1 1v2c0 .5522847-.4477153 1-1 1z"/><path id="Shape" d="m34 8h-4c-.5522847 0-1-.44771525-1-1s.4477153-1 1-1h4c.5522847 0 1 .44771525 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m53 8h-14c-.5522847 0-1-.44771525-1-1s.4477153-1 1-1h14c.5522847 0 1 .44771525 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m34 23h-4c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h4c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m53 23h-14c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h14c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m41 13h-11c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h11c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m53 13h-6c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h6c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m32 18h-2c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h2c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m45 18h-9c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h9c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m53 18h-4c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h4c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/></g></g></g></svg><?php }
}
