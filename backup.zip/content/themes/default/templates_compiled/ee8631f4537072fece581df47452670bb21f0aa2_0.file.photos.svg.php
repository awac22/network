<?php
/* Smarty version 3.1.40, created on 2022-12-08 04:45:14
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/photos.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_63916bda87eff1_86662203',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ee8631f4537072fece581df47452670bb21f0aa2' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/photos.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63916bda87eff1_86662203 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 58 51" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Page-1" fill="none" fill-rule="evenodd"><g id="034---Gallery" fill-rule="nonzero"><path id="Shape" d="m6 9v-3c0-3.3137085 2.6862915-6 6-6h40c3.3137085 0 6 2.6862915 6 6v30c0 3.3137085-2.6862915 6-6 6z" fill="#547580"/><rect id="Rectangle-path" fill="#ecf0f1" height="42" rx="6" width="52" y="9"/><path id="Shape" d="m46 47c1.1045695 0 2-.8954305 2-2v-30c0-1.1045695-.8954305-2-2-2h-40c-1.1045695 0-2 .8954305-2 2v30c0 1.1045695.8954305 2 2 2z" fill="#84b5cb"/><circle id="Oval" cx="31" cy="21" fill="#f0c419" r="3"/><path id="Shape" d="m48 27v18c-.0032948 1.1032019-.8967981 1.9967052-2 2h-10c-1.872228-4.9536834-4.8752844-9.4017682-8.77-12.99 6.078217-4.3383401 13.3059546-6.777745 20.77-7.01z" fill="#5d4c72"/><path id="Shape" d="m36 47h-30c-1.10320187-.0032948-1.9967052-.8967981-2-2v-20c3.33.08 14.36.98 23.23 9.01 3.8947156 3.5882318 6.897772 8.0363166 8.77 12.99z" fill="#955ba5"/></g></g></svg><?php }
}
