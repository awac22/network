<?php
/* Smarty version 3.1.40, created on 2022-07-01 12:51:13
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/browser_notifications.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62beedc1bc34f1_58368386',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bc286cf1d0c2a4d2dccd79aaf5bfe2d8b7b47aaa' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/browser_notifications.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62beedc1bc34f1_58368386 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 58 58" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Page-1" fill="none" fill-rule="evenodd"><g id="053---browser-alert" fill-rule="nonzero"><path id="Shape" d="m54 34v20c0 2.209139-1.790861 4-4 4h-46c-2.209139 0-4-1.790861-4-4v-36h32z" fill="#9fc9d3"/><path id="Shape" d="m32.69 12c-.4593213 1.2834682-.6927745 2.6368202-.69 4v4h-32v-4c0-2.209139 1.790861-4 4-4z" fill="#285680"/><circle id="Oval" cx="4" cy="16" fill="#e64c3c" r="1"/><circle id="Oval" cx="8" cy="16" fill="#f0c419" r="1"/><circle id="Oval" cx="12" cy="16" fill="#4fba6f" r="1"/><g fill="#fff"><path id="Shape" d="m7 46h-2c-.55228475 0-1-.4477153-1-1s.44771525-1 1-1h2c.55228475 0 1 .4477153 1 1s-.44771525 1-1 1z"/><path id="Shape" d="m26 46h-15c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h15c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m7 54h-2c-.55228475 0-1-.4477153-1-1s.44771525-1 1-1h2c.55228475 0 1 .4477153 1 1s-.44771525 1-1 1z"/><path id="Shape" d="m26 54h-15c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h15c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m26 49h-2"/><path id="Shape" d="m26 50h-2c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h2c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m20 50h-15c-.55228475 0-1-.4477153-1-1s.44771525-1 1-1h15c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/></g><path id="Shape" d="m56 16 .0000265 13h-24.0000509l.0000244-13c-.0027745-1.3631798.2306787-2.7165318.69-4 1.2144222-3.43679757 3.9266443-6.13429928 7.37-7.33 2.5507137-.89331556 5.3292863-.89331556 7.88 0 1.7139136.58621531 3.2705028 1.55780068 4.55 2.84 2.2534177 2.24999143 3.5166967 5.305615 3.51 8.49z" fill="#e64c3c"/><path id="Shape" d="m36 17c-.5522847 0-1-.4477153-1-1 .0055111-4.9682782 4.0317218-8.99448887 9-9 .5522847 0 1 .44771525 1 1s-.4477153 1-1 1c-3.8641657.00440864-6.9955914 3.1358343-7 7 0 .5522847-.4477153 1-1 1z" fill="#fff"/><path id="Shape" d="m58 31v2c0 .5522847-.4477153 1-1 1h-26c-.5522847 0-1-.4477153-1-1v-2c.0032948-1.1032019.8967981-1.9967052 2-2h24c1.1032019.0032948 1.9967052.8967981 2 2z" fill="#c03a2b"/><path id="Shape" d="m36 24c-.5522847 0-1-.4477153-1-1v-3c0-.5522847.4477153-1 1-1s1 .4477153 1 1v3c0 .5522847-.4477153 1-1 1z" fill="#fff"/><path id="Shape" d="m49 34c0 2.7614237-2.2385763 5-5 5s-5-2.2385763-5-5z" fill="#802f34"/><path id="Shape" d="m48 4c.00033.22468945-.0197526.44894435-.06.67-2.5507137-.89331556-5.3292863-.89331556-7.88 0-.0402474-.22105565-.06033-.44531055-.06-.67 0-2.209139 1.790861-4 4-4s4 1.790861 4 4z" fill="#c03a2b"/></g></g></svg><?php }
}
