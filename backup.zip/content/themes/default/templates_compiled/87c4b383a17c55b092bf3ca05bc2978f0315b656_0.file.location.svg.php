<?php
/* Smarty version 3.1.40, created on 2022-07-01 12:49:36
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/location.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62beed607a8d16_78727012',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '87c4b383a17c55b092bf3ca05bc2978f0315b656' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/location.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62beed607a8d16_78727012 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 128 128" width="512" xmlns="http://www.w3.org/2000/svg"><g><path d="m107.427 84.289h-30.155a182.929 182.929 0 0 1 -13.272 18.371 182.929 182.929 0 0 1 -13.272-18.371h-30.155l-14.267 37.405h115.388z" fill="#dfeef4"/><path d="m64 6.31a30.711 30.711 0 0 0 -30.71 30.71c-.18 29.3 30.71 65.64 30.71 65.64s30.89-36.34 30.71-65.64a30.711 30.711 0 0 0 -30.71-30.71zm0 43.74a13.03 13.03 0 1 1 13.03-13.03 13.025 13.025 0 0 1 -13.03 13.03z" fill="#f45858"/><path d="m110.74 92.96-57.58 20.48-22.44-29.15h20.01a182.752 182.752 0 0 0 13.27 18.37 182.752 182.752 0 0 0 13.27-18.37h30.16z" fill="#f2da30"/><path d="m29.96 121.694 56.996-20.274 15.604 20.274z" fill="#3ea2e5"/></g></svg><?php }
}
