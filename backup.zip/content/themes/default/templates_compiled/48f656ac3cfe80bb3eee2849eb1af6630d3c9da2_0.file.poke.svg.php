<?php
/* Smarty version 3.1.40, created on 2022-04-15 12:24:12
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/poke.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_625963ec2cd537_21027844',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '48f656ac3cfe80bb3eee2849eb1af6630d3c9da2' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/poke.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_625963ec2cd537_21027844 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<path style="fill:#FEC478;" d="M467,155.779H321.21l-47.52-47.5c-27.13-27.15-70.14-29.49-100.08-5.62l-107.99,86.4
	c-3.54,2.86-5.62,7.16-5.62,11.72v180c0,6.08,3.66,11.56,9.29,13.87l5.21,2.14c47.76,19.23,98.41,28.99,150.5,28.99h60
	c24.81,0,45-20.19,45-45c0-5.84-1.11-11.44-3.16-16.58c19.1-5.2,33.16-22.71,33.16-43.42c0-5.84-1.11-11.44-3.16-16.58
	c8.49-2.31,15.98-7.05,21.67-13.42c7.15-7.97,11.49-18.49,11.49-30c0-5.26-0.91-10.31-2.58-15H467c24.81,0,45-20.19,45-45
	S491.81,155.779,467,155.779z"/>
<path style="fill:#FEB756;" d="M356.84,304.199c2.05,5.14,3.16,10.74,3.16,16.58c0,20.71-14.06,38.22-33.16,43.42
	c2.05,5.14,3.16,10.74,3.16,16.58c0,24.81-20.19,45-45,45h-60c-52.09,0-102.74-9.76-150.5-28.99l-5.21-2.14
	c-5.63-2.31-9.29-7.79-9.29-13.87v-90h318.51C372.82,297.15,365.33,301.889,356.84,304.199z"/>
<path style="fill:#FD003A;" d="M45,425.779H15c-8.291,0-15-6.709-15-15v-240c0-8.291,6.709-15,15-15h30c24.814,0,45,20.186,45,45
	v180C90,405.594,69.814,425.779,45,425.779z"/>
<path style="fill:#E50027;" d="M0,290.779v120c0,8.291,6.709,15,15,15h30c24.814,0,45-20.186,45-45v-90H0z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
