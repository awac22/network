<?php
/* Smarty version 3.1.40, created on 2022-12-15 23:37:56
  from '8a12327029543f0cac9a30eafd09648376e28a8f' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_639bafd41c7dc6_58550990',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_639bafd41c7dc6_58550990 (Smarty_Internal_Template $_smarty_tpl) {
?><p><strong>Who can use this service?</strong></p>
<p><span style="font-weight: 400;">Those users can use this service who provide the following:</span></p>
<ol>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">The same name is provided that is used in the everyday life of the user.</span></li>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">The accurate information about themselves.</span></li>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">To only create one account .</span></li>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">The users are advised not to share the passwords and give access to anyone other than themselves.</span></li>
</ol>
<p>&nbsp;</p>
<p><strong>Who can not use this service?</strong></p>
<p><span style="font-weight: 400;">It is our first priority to make this service available to everyone but you cannot use this service if you are.</span></p>
<ol>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Under the age of 13</span></li>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Are a convicted sex offender</span></li>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">If you are prohibited from using our service under any law.</span></li>
</ol>
<p>&nbsp;</p>
<p><strong>What can you share?</strong></p>
<p><span style="font-weight: 400;">&nbsp;We at AWAC want our users to be able to express themselves and to share their content with everyone around the world, but such liberty shall not be at the expense of the safety of others.</span></p>
<ol>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">You may not use our products to do or share anything</span></li>
</ol>
<ol>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Anything that is unlawful or discriminatory.</span></li>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Anything you do not own or have any rights to share.</span></li>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">Anything that infringes the rights of others, which includes rights of intellectual property.</span></li>
</ol>
<p>&nbsp;</p>
<ol>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">The user must not at any cost upload viruses or use the service to send spam or do anything that could possibly harm the working of the service.</span></li>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">The user may not use and collect our data using automated means.</span></li>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">The user may not sell or purchase any data that has been obtained from our service.</span></li>
<li style="font-weight: 400;" aria-level="1"><span style="font-weight: 400;">The service can restrict the access to content which is in violation of the provisions and can also suspend or disable any account on the same grounds.</span></li>
</ol>
<p>&nbsp;</p>
<p><strong>Permission you give us:</strong></p>
<ul>
<li aria-level="1"><strong>Permission to use the content you create and share:<br /><br /></strong>The content that you upload such as pictures, videos will be protected by intellectual property laws.<br /><br />The user that posts the content has ownership of all the intellectual property rights. Users are free to share their content with anyone at any time.</li>
</ul>
<p><span style="font-weight: 400;">In order to provide our services the user will have to give the service legal permissions to use the content. Which will be used to improve the services.</span></p>
<p>&nbsp;</p>
<ul>
<li aria-level="1"><strong>Permission to update software that you use or download:<br /><br /></strong>If the user downloads or use our software th use will be giving us permission to download and install updates to the software where available</li>
</ul>
<p>&nbsp;</p>
<ul>
<li aria-level="1"><strong>Limits on using our intellectual property:<br /><br /></strong>If the user uses content covered by the intellectual property right that we have and make available in our products. All the rights of the content are retained .</li>
</ul>
<p>&nbsp;</p>
<ul>
<li aria-level="1"><strong>Updating our Terms:<br /><br /></strong>Our teams work hard to improve our services and constantly develop new features to make your experience better for our users and our community. Which may result in us updating our terms from time to time in order to&nbsp; promote a safe and secure environment.</li>
</ul>
<p>&nbsp;</p>
<ul>
<li aria-level="1"><strong>Account suspension and termination:<br /><br /></strong>We at AWAC want this platform to be a safe place for all to feel welcomed and be able to express themselves.<br /><br />In a case where constant breach of terms and agreements take place we may temporarily or permanently disable or terminate your account.</li>
</ul><?php }
}
