<?php
/* Smarty version 3.1.40, created on 2022-04-06 17:19:07
  from '/home/anywhereanycity/public_html/network/Script/content/themes/default/images/svg/popularity.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_624dcb8bb0b277_71751606',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '214c7b75d3b2908f3aadca6cefccbe45c76d16b2' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/Script/content/themes/default/images/svg/popularity.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624dcb8bb0b277_71751606 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Capa_1" enable-background="new 0 0 512.016 512.016" height="512" viewBox="0 0 512.016 512.016" width="512" xmlns="http://www.w3.org/2000/svg"><g><path d="m475.278 99.896-40.73-32.13 3.38-51.77c.41-6.2-2.84-11.28-7.48-13.95-4.63-2.68-10.66-2.94-15.82.5l-43.14 28.8-48.2-19.2c-11.53-4.6-23.35 6.05-19.99 18l14.07 49.93-33.16 39.9c-7.94 9.55-1.46 24.09 10.94 24.58l51.84 2.05 27.69 43.87c6.65 10.52 22.47 8.79 26.76-2.81l17.97-48.67 50.28-12.79c12.03-3.06 15.34-18.63 5.59-26.31z" fill="#fed843"/><path d="m146.008 422.016h-131c-8.284 0-15 6.716-15 15v60c0 8.284 6.716 15 15 15h131c8.284 0 15-6.716 15-15v-60c0-8.284-6.716-15-15-15z" fill="#fed843"/><path d="m271.008 362.016h-125c-8.284 0-15 6.716-15 15v135h140c8.284 0 15-6.716 15-15v-120c0-8.284-6.716-15-15-15z" fill="#ffb64c"/><path d="m386.008 302.016h-115c-8.284 0-15 6.716-15 15v195h130c8.284 0 15-6.716 15-15v-180c0-8.284-6.716-15-15-15z" fill="#fed843"/><path d="m497.008 512.016h-126v-255c0-8.284 6.716-15 15-15h111c8.284 0 15 6.716 15 15v240c0 8.284-6.716 15-15 15z" fill="#ffb64c"/><path d="m76.008 332.016c-8.284 0-15-6.716-15-15 0-24.813 20.187-45 45-45h60c8.271 0 15-6.729 15-15 0-24.813 20.187-45 45-45h60c8.271 0 15-6.729 15-15 0-8.284 6.716-15 15-15s15 6.716 15 15c0 24.813-20.187 45-45 45h-60c-8.271 0-15 6.729-15 15 0 24.813-20.187 45-45 45h-60c-8.271 0-15 6.729-15 15 0 8.284-6.716 15-15 15z" fill="#efe2dd"/><path d="m469.688 126.206-50.28 12.79-17.97 48.67c-4.29 11.6-20.11 13.33-26.76 2.81l-27.69-43.87 83.46-144.56c4.64 2.67 7.89 7.75 7.48 13.95l-3.38 51.77 40.73 32.13c9.75 7.68 6.44 23.25-5.59 26.31z" fill="#ffb64c"/></g></svg><?php }
}
