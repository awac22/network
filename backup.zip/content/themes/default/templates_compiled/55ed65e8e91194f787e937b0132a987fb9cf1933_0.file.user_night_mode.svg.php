<?php
/* Smarty version 3.1.40, created on 2022-04-06 17:25:26
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/user_night_mode.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_624dcd0614f005_43992911',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '55ed65e8e91194f787e937b0132a987fb9cf1933' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/user_night_mode.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624dcd0614f005_43992911 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 496 496" style="enable-background:new 0 0 496 496;" xml:space="preserve">
<path style="fill:#576063;" d="M383.6,496L370,400.8l-65.6-22.4V376l-16-6.4v2.4l-7.2-1.6h-0.8c0,0-3.2-3.2-6.4-2.4
	c-0.8,0-0.8,0-1.6,0h-0.8l2.4-5.6l-29.6-12.8l-5.6,4l-1.6-20c0.8-1.6,2.4-2.4,3.2-4c19.2-27.2,20.8-65.6,20.8-87.2
	c0-15.2,4-20,5.6-24c0.8-1.6,1.6-3.2,2.4-4.8c4-12.8-7.2-62.4-49.6-64c-6.4-11.2-36.8-16-68.8-5.6c-34.4,12-29.6,37.6-29.6,37.6
	c-16,12-6.4,33.6-6.4,33.6c-4.8,12,7.2,18.4,9.6,20c0,2.4,0,4,0,7.2c-0.8,21.6,0.8,60,20.8,87.2c0.8,1.6,1.6,2.4,3.2,4l-3.2,18.4
	l-4-2.4l-29.6,12.8l1.6,5.6h-2.4l0,0c0,0-0.8,0-1.6,0c-3.2-0.8-5.6,2.4-5.6,2.4l-1.6,0.8l-5.6,0.8v-2.4l-16,6.4v2.4l-65.6,22.4
	L0.4,496H383.6z"/>
<path style="fill:#333B3D;" d="M218.8,148.8c-6.4-11.2-36.8-16-68.8-5.6c-34.4,12-29.6,37.6-29.6,37.6c-16,12-6.4,33.6-6.4,33.6
	c-4.8,12,7.2,18.4,9.6,20c0,2.4,0,4,0,7.2c-0.8,21.6,0.8,60,20.8,87.2c0.8,1.6,1.6,2.4,3.2,4l-2.4,19.2l-4-2.4l-16,6.4l148,140
	h109.6l-13.6-95.2l-64.8-22.4V376l-16-6.4v2.4l-7.2-1.6h-0.8c0,0-3.2-3.2-6.4-2.4c-0.8,0-0.8,0-1.6,0h-0.8l2.4-5.6l-29.6-12.8
	l-5.6,4l-1.6-20c0.8-1.6,2.4-2.4,3.2-4c19.2-27.2,20.8-65.6,20.8-87.2c0-15.2,4-20,5.6-24c0.8-1.6,1.6-3.2,2.4-4.8
	c2.4-6.4,0-21.6-7.2-36l-24-24C231.6,150.4,225.2,148.8,218.8,148.8z"/>
<path style="fill:#F7B208;" d="M454.8,160.8c-64,0-116-52-116-116c0-16,3.2-31.2,8.8-44.8c-44,16.8-75.2,58.4-75.2,108
	c0,64,52,116,116,116c48,0,88.8-29.6,106.4-71.2C482.8,158.4,469.2,160.8,454.8,160.8z"/>
<path style="fill:#EDA503;" d="M339.6,44.8c0-16,3.2-31.2,8.8-44.8c-12,4.8-23.2,11.2-33.6,19.2c-7.2,15.2-11.2,32-11.2,50.4
	c0,64,52,116,116,116c28,0,53.6-10.4,73.6-26.4c0.8-1.6,1.6-4,2.4-5.6c-12.8,4.8-26.4,7.2-40.8,7.2
	C391.6,160.8,339.6,108.8,339.6,44.8z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
