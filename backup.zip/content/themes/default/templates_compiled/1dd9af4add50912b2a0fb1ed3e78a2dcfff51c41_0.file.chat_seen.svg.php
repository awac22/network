<?php
/* Smarty version 3.1.40, created on 2022-07-01 12:51:12
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/chat_seen.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62beedc0387d64_60957450',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1dd9af4add50912b2a0fb1ed3e78a2dcfff51c41' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/chat_seen.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62beedc0387d64_60957450 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Capa_1" enable-background="new 0 0 512 512" height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg"><g><path d="m512 154.352-49.532-49.532-49.532 49.531-203.292 104.237-61.05-61.05-49.532 49.532 51.046 61.047 59.535 49.534 49.529 49.529z" fill="#2681ff"/><path d="m412.938 154.352-49.532-49.532-203.296 203.295-110.577-110.577-49.533 49.532 160.11 160.11z" fill="#69b1e9"/></g></svg><?php }
}
