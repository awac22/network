<?php
/* Smarty version 3.1.40, created on 2022-12-08 04:45:14
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/audios.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_63916bda8a4cb1_00281696',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5a8f266f642d95e2e7d5010e49c66f93d90fca29' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/audios.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63916bda8a4cb1_00281696 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 48 58" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Page-1" fill="none" fill-rule="evenodd"><g id="076---Microphone" fill-rule="nonzero"><path id="Shape" d="m28 48h-8c-8.2803876-.0093685-14.99063148-6.7196124-15-15v-3c0-.5522847.44771525-1 1-1s1 .4477153 1 1v3c.00826602 7.1762751 5.8237249 12.991734 13 13h8c7.1762751-.008266 12.991734-5.8237249 13-13v-3c0-.5522847.4477153-1 1-1s1 .4477153 1 1v3c-.0093685 8.2803876-6.7196124 14.9906315-15 15z" fill="#bdc3c7"/><path id="Shape" d="m36 8v20h-24v-20c0-4.418278 3.581722-8 8-8h8c4.418278 0 8 3.581722 8 8z" fill="#3f5c6c"/><path id="Shape" d="m36 32v2c0 4.418278-3.581722 8-8 8h-8c-4.418278 0-8-3.581722-8-8v-2z" fill="#46b29d"/><g fill="#547580"><circle id="Oval" cx="17" cy="7" r="1"/><circle id="Oval" cx="17" cy="11" r="1"/><circle id="Oval" cx="17" cy="15" r="1"/><circle id="Oval" cx="17" cy="19" r="1"/><circle id="Oval" cx="17" cy="23" r="1"/><circle id="Oval" cx="25" cy="7" r="1"/><circle id="Oval" cx="25" cy="11" r="1"/><circle id="Oval" cx="25" cy="15" r="1"/><circle id="Oval" cx="25" cy="19" r="1"/><circle id="Oval" cx="25" cy="23" r="1"/><circle id="Oval" cx="21" cy="5" r="1"/><circle id="Oval" cx="21" cy="9" r="1"/><circle id="Oval" cx="21" cy="13" r="1"/><circle id="Oval" cx="21" cy="17" r="1"/><circle id="Oval" cx="21" cy="21" r="1"/></g><path id="Rectangle-path" d="m12 28h24v4h-24z" fill="#65ddb9"/><path id="Rectangle-path" d="m22 42h4v12h-4z" fill="#14a085"/><path id="Shape" d="m17 54h14c1.6568542 0 3 1.3431458 3 3 0 .5522847-.4477153 1-1 1h-18c-.5522847 0-1-.4477153-1-1 0-1.6568542 1.3431458-3 3-3z" fill="#41767f"/><rect id="Rectangle-path" fill="#14a085" height="10" rx="1" width="4" x="4" y="20"/><path id="Rectangle-path" d="m8 23h4v4h-4z" fill="#65ddb9"/><path id="Shape" d="m2 23h2v4h-2c-1.1045695 0-2-.8954305-2-2s.8954305-2 2-2z" fill="#65ddb9"/><rect id="Rectangle-path" fill="#14a085" height="10" rx="1" transform="matrix(-1 0 0 -1 84 50)" width="4" x="40" y="20"/><path id="Rectangle-path" d="m36 23h4v4h-4z" fill="#65ddb9" transform="matrix(-1 0 0 -1 76 50)"/><path id="Shape" d="m46 23h2v4h-2c-1.1045695 0-2-.8954305-2-2s.8954305-2 2-2z" fill="#65ddb9" transform="matrix(-1 0 0 -1 92 50)"/></g></g></svg><?php }
}
