<?php
/* Smarty version 3.1.40, created on 2022-04-06 17:20:30
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/saved.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_624dcbdeaf8a46_82052641',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6968971661b7f9f28ad6bcbb35e0023652f5992d' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/saved.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624dcbdeaf8a46_82052641 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<circle style="fill:#3BB54A;" cx="256" cy="139.6" r="128"/>
<g>
	<path style="fill:#8FCC92;" d="M186.2,67.5c-1.2,0-3.5-1.2-4.7-2.3c-2.3-2.3-2.3-5.8,0-8.1c10.5-9.3,23.3-17.5,37.2-22.1
		c3.5-1.2,5.8,0,7,3.5s0,5.8-3.5,7C210.6,50,199,55.9,189.7,65.2C188.5,67.5,187.3,67.5,186.2,67.5z"/>
	<path style="fill:#8FCC92;" d="M151.3,145.5c-3.5,0-5.8-2.3-5.8-5.8c0-17.5,3.5-33.7,11.6-48.9c1.2-2.3,4.7-3.5,8.1-2.3
		c2.3,1.2,3.5,4.7,2.3,8.1c-7,14-10.5,29.1-10.5,44.2C157.1,143.1,154.8,145.5,151.3,145.5z"/>
</g>
<path style="fill:#0E9347;" d="M327,33.7c14,19.8,22.1,44.2,22.1,71c0,71-57,128-128,128c-26.8,0-51.2-8.1-71-22.1
	c23.3,33.7,61.7,57,105.9,57c71,0,128-57,128-128C384,95.4,361.9,55.9,327,33.7z"/>
<path id="SVGCleanerId_0" style="fill:#C97629;" d="M290.9,500.4H58.2c-7,0-11.6-4.7-11.6-11.6V209.5H291v290.9H290.9z"/>
<g>
	<path id="SVGCleanerId_0_1_" style="fill:#C97629;" d="M290.9,500.4H58.2c-7,0-11.6-4.7-11.6-11.6V209.5H291v290.9H290.9z"/>
</g>
<path id="SVGCleanerId_1" style="fill:#B06328;" d="M290.9,500.4h162.9c7,0,11.6-4.7,11.6-11.6V209.5H290.9V500.4z"/>
<g>
	<path id="SVGCleanerId_1_1_" style="fill:#B06328;" d="M290.9,500.4h162.9c7,0,11.6-4.7,11.6-11.6V209.5H290.9V500.4z"/>
</g>
<path style="fill:#B06328;" d="M58.2,488.7V349.1c0-12.8,10.5-23.3,23.3-23.3h176.9c5.8,0,10.5-3.5,11.6-9.3l20.9-107.1H58.2H46.5
	v116.4v162.9c0,7,4.7,11.6,11.6,11.6h232.7c-7-7-17.5-11.6-27.9-11.6H58.2z"/>
<path style="fill:#A35425;" d="M453.8,209.5H290.9l20.9,107.1c1.2,5.8,5.8,9.3,11.6,9.3h107.1c12.8,0,23.3,10.5,23.3,23.3v139.6
	h-135c-10.5,0-20.9,4.7-27.9,11.6h162.9c7,0,11.6-4.7,11.6-11.6v-163V209.5H453.8z"/>
<path style="fill:#C97629;" d="M361.9,302.5h138.5c7,0,11.6-5.8,11.6-11.6c0-2.3,0-4.7-2.3-5.8l-44.2-75.6H290.9l51.2,82.6
	C346.8,297.9,353.7,302.5,361.9,302.5z"/>
<path style="fill:#DA8C36;" d="M219.9,302.5H11.6c-7,0-11.6-5.8-11.6-11.6c0-2.3,0-4.7,2.3-5.8l44.2-75.6h244.4l-51.2,82.6
	C235.1,297.9,228.1,302.5,219.9,302.5z"/>
<g>
	<path style="fill:#FFCB5B;" d="M75.6,418.9h69.8c3.5,0,5.8,2.3,5.8,5.8l0,0c0,3.5-2.3,5.8-5.8,5.8H75.6c-3.5,0-5.8-2.3-5.8-5.8l0,0
		C69.8,421.2,72.1,418.9,75.6,418.9z"/>
	<path style="fill:#FFCB5B;" d="M75.6,442.2h46.5c3.5,0,5.8,2.3,5.8,5.8l0,0c0,3.5-2.3,5.8-5.8,5.8H75.6c-3.5,0-5.8-2.3-5.8-5.8l0,0
		C69.8,444.5,72.1,442.2,75.6,442.2z"/>
</g>
<path style="fill:#0E9347;" d="M256,184.5c-2.6,0-5.1-1-7.1-2.9L214,146.7c-3.9-3.9-3.9-10.2,0-14.1s10.2-3.9,14.1,0l27.8,27.8
	l62.7-62.7c3.9-3.9,10.2-3.9,14.1,0s3.9,10.2,0,14.1l-69.8,69.8C261.1,183.6,258.6,184.5,256,184.5z"/>
<path style="fill:#FFFFFF;" d="M244.4,172.9c-2.7,0-5.2-1.1-7.1-2.9l-34.9-34.9c-3.9-3.9-3.9-10.2,0-14.1s10.2-3.9,14.1,0l27.8,27.8
	L307.1,86c3.9-3.9,10.2-3.9,14.1,0s3.9,10.2,0,14.1L251.4,170C249.6,171.9,247,172.9,244.4,172.9z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
