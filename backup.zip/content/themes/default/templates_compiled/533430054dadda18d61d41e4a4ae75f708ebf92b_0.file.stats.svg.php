<?php
/* Smarty version 3.1.40, created on 2022-04-15 12:24:12
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/stats.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_625963ec2c0db0_63820112',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '533430054dadda18d61d41e4a4ae75f708ebf92b' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/stats.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_625963ec2c0db0_63820112 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<path style="fill:#FEC7B0;" d="M144,318.5H64c-4.418,0-8,3.582-8,8v176c0,4.418,3.582,8,8,8h80c4.418,0,8-3.582,8-8v-176
	C152,322.082,148.418,318.5,144,318.5z"/>
<g>
	<path style="fill:#FEAA88;" d="M80,502.5v-176c0-4.418,3.582-8,8-8H64c-4.418,0-8,3.582-8,8v176c0,4.418,3.582,8,8,8h24
		C83.582,510.5,80,506.918,80,502.5z"/>
	<path style="fill:#FEAA88;" d="M296,278.5h-80c-4.418,0-8,3.582-8,8v216c0,4.418,3.582,8,8,8h80c4.418,0,8-3.582,8-8v-216
		C304,282.082,300.418,278.5,296,278.5z"/>
</g>
<g>
	<path style="fill:#FD8E61;" d="M232,502.5v-216c0-4.418,3.582-8,8-8h-24c-4.418,0-8,3.582-8,8v216c0,4.418,3.582,8,8,8h24
		C235.582,510.5,232,506.918,232,502.5z"/>
	<path style="fill:#FD8E61;" d="M448,190.5h-80c-4.418,0-8,3.582-8,8v304c0,4.418,3.582,8,8,8h80c4.418,0,8-3.582,8-8v-304
		C456,194.082,452.418,190.5,448,190.5z"/>
</g>
<path style="fill:#FD7239;" d="M384,502.5v-304c0-4.418,3.582-8,8-8h-24c-4.418,0-8,3.582-8,8v304c0,4.418,3.582,8,8,8h24
	C387.582,510.5,384,506.918,384,502.5z"/>
<path style="fill:#AAB4BD;" d="M504,510.5H8c-4.418,0-8-3.582-8-8s3.582-8,8-8h496c4.418,0,8,3.582,8,8S508.418,510.5,504,510.5z"/>
<path style="fill:#55697A;" d="M482.589,5.506c-3.44-3.038-8.023-4.452-12.573-3.882l-64,8c-8.769,1.096-14.988,9.093-13.892,17.861
	c1.096,8.77,9.102,14.983,17.86,13.892l24.068-3.008C352.648,139.657,252.56,191.285,180.743,217.031
	C96.902,247.087,32.145,249.488,31.5,249.508c-8.825,0.275-15.76,7.649-15.492,16.477c0.262,8.667,7.371,15.515,15.983,15.515
	c0.164,0,0.328-0.002,0.493-0.007c2.798-0.085,69.531-2.438,157.886-33.921c51.829-18.468,100.393-43.206,144.341-73.527
	C380.307,142.587,420.976,105.012,456,62.097V81.5c0,8.836,7.163,16,16,16s16-7.164,16-16v-64
	C488,12.911,486.029,8.543,482.589,5.506z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
