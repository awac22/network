<?php
/* Smarty version 3.1.40, created on 2022-07-01 12:49:36
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/biography.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62beed607a3ab9_67011980',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '30bc8e300bd3bb46eb7893452799dc17fd9817d3' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/biography.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62beed607a3ab9_67011980 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Flat" enable-background="new 0 0 64 64" height="512" viewBox="0 0 64 64" width="512" xmlns="http://www.w3.org/2000/svg"><path d="m49 51h-41c-2.761 0-5 2.239-5 5v-46c0-2.761 2.239-5 5-5h41z" fill="#454a6d"/><path d="m49 61h-41c-2.761 0-5-2.239-5-5 0-2.761 2.239-5 5-5h41z" fill="#dbd8d5"/><path d="m35 38v-9l26-26v8.059c0 6.365-2.529 12.47-7.029 16.971l-9.971 9.97z" fill="#f7f4f0"/><path d="m24.029 31h33.941v2h-33.941z" fill="#e89d43" transform="matrix(.707 -.707 .707 .707 -10.619 38.364)"/><circle cx="26" cy="19" fill="#33385c" r="9"/><circle cx="26" cy="17" fill="#4ac3ed" r="3"/><path d="m26 20c-3.215 0-5.832 2.531-5.985 5.708 1.591 1.421 3.684 2.292 5.985 2.292s4.394-.871 5.985-2.292c-.153-3.177-2.77-5.708-5.985-5.708z" fill="#4ac3ed"/><g fill="#33385c"><path d="m17 43h10v2h-10z"/><path d="m17 38h13v2h-13z"/><path d="m17 33h15v2h-15z"/></g></svg><?php }
}
