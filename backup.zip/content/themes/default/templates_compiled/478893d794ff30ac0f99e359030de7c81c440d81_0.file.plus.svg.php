<?php
/* Smarty version 3.1.40, created on 2022-04-06 17:19:07
  from '/home/anywhereanycity/public_html/network/Script/content/themes/default/images/svg/plus.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_624dcb8bbc8040_74269160',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '478893d794ff30ac0f99e359030de7c81c440d81' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/Script/content/themes/default/images/svg/plus.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624dcb8bbc8040_74269160 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512pt" viewBox="0 0 512 512" width="512pt" xmlns="http://www.w3.org/2000/svg"><path d="m256 0c-141.164062 0-256 114.835938-256 256s114.835938 256 256 256 256-114.835938 256-256-114.835938-256-256-256zm0 0" fill="#2196f3"/><path d="m368 277.332031h-90.667969v90.667969c0 11.777344-9.554687 21.332031-21.332031 21.332031s-21.332031-9.554687-21.332031-21.332031v-90.667969h-90.667969c-11.777344 0-21.332031-9.554687-21.332031-21.332031s9.554687-21.332031 21.332031-21.332031h90.667969v-90.667969c0-11.777344 9.554687-21.332031 21.332031-21.332031s21.332031 9.554687 21.332031 21.332031v90.667969h90.667969c11.777344 0 21.332031 9.554687 21.332031 21.332031s-9.554687 21.332031-21.332031 21.332031zm0 0" fill="#fafafa"/></svg><?php }
}
