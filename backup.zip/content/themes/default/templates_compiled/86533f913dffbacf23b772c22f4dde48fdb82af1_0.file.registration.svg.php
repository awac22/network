<?php
/* Smarty version 3.1.40, created on 2022-07-01 12:49:34
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/registration.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62beed5eda5f57_52745807',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '86533f913dffbacf23b772c22f4dde48fdb82af1' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/registration.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62beed5eda5f57_52745807 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 442.648 442.648" style="enable-background:new 0 0 442.648 442.648;" xml:space="preserve">
<g>
	<g>
		<g>
			<g id="XMLID_27_">
				<g>
					<path style="fill:#1EA6C6;" d="M265.467,353.083c0,23.73,8.69,45.47,23.07,62.2c-13.66,2.57-27.76,3.91-42.16,3.91
						c-58.79,0-112.38-22.3-152.75-58.91v-0.13c0-60.89,35.63-113.45,87.17-137.98c19.37,19.32,42.05,29.73,65.58,29.73
						c23.54,0,46.21-10.41,65.59-29.73c18.09,8.61,34.22,20.67,47.53,35.34C307.497,258.344,265.467,300.893,265.467,353.083z"/>
					<path style="fill:#FCD09F;" d="M246.375,29.858c46.66,0,84.49,37.82,84.49,84.48c0,46.67-37.83,110.49-84.49,110.49
						s-84.49-63.82-84.49-110.49C161.885,67.678,199.715,29.858,246.375,29.858z"/>
				</g>
			</g>
		</g>
		<g>
			<g id="XMLID_22_">
				<g>
					<path style="fill:#EF806F;" d="M175.17,195.124c2.59,3.69,5.27,7.15,8.04,10.4l-8.43,4.01c-28.06,13.35-51.8,34.24-68.67,60.41
						c-13.72,21.29-22.32,45.29-25.31,70.31c-30.49-8.31-58.05-23.72-80.8-44.35v-0.11c0-53.06,31.05-98.86,75.96-120.24
						c16.88,16.84,36.64,25.91,57.14,25.91c13.43,0,26.55-3.89,38.74-11.31C172.91,191.835,174.03,193.495,175.17,195.124z"/>
					<path style="fill:#EFC59C;" d="M147.89,114.335c0,17.54,4.56,36.84,12.68,54.98c-8.49,5.38-17.76,8.55-27.47,8.55
						c-40.66,0-73.62-55.61-73.62-96.28c0-40.66,32.96-73.61,73.62-73.61c22.55,0,42.74,10.14,56.24,26.11
						C164.27,51.965,147.89,81.275,147.89,114.335z"/>
				</g>
			</g>
		</g>
	</g>
	<circle style="fill:#EF806F;" cx="361.057" cy="353.083" r="81.591"/>
	<rect x="304.645" y="345.583" style="fill:#FFFFFF;" width="112.822" height="15"/>
	<rect x="353.556" y="296.672" style="fill:#FFFFFF;" width="15" height="112.822"/>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
