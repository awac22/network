<?php
/* Smarty version 3.1.40, created on 2022-07-01 12:50:54
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/credit_card.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62beedae289665_87990056',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '296f6a6acf6e18be479e9fcc46577a11f0cca8c2' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/credit_card.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62beedae289665_87990056 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 464 464" style="enable-background:new 0 0 464 464;" xml:space="preserve">
<path style="fill:#CCCCCC;" d="M24,80h416c13.255,0,24,10.745,24,24v256c0,13.255-10.745,24-24,24H24c-13.255,0-24-10.745-24-24V104
	C0,90.745,10.745,80,24,80z"/>
<path style="fill:#29ABE2;" d="M440,80H216.856c8.805,83.453,83.596,143.967,167.049,135.162
	c29.374-3.099,57.207-14.693,80.095-33.362V104C464,90.745,453.255,80,440,80z"/>
<rect x="40" y="120" style="fill:#FBB03B;" width="96" height="64"/>
<g>
	<rect x="32" y="240" style="fill:#808080;" width="16" height="16"/>
	<rect x="64" y="240" style="fill:#808080;" width="16" height="16"/>
	<rect x="96" y="240" style="fill:#808080;" width="16" height="16"/>
	<rect x="128" y="240" style="fill:#808080;" width="16" height="16"/>
	<rect x="160" y="240" style="fill:#808080;" width="16" height="16"/>
	<rect x="192" y="240" style="fill:#808080;" width="16" height="16"/>
	<rect x="224" y="240" style="fill:#808080;" width="16" height="16"/>
	<rect x="256" y="240" style="fill:#808080;" width="16" height="16"/>
	<rect x="288" y="240" style="fill:#808080;" width="16" height="16"/>
</g>
<circle style="fill:#DA4836;" cx="344" cy="312" r="32"/>
<path style="fill:#F7931E;" d="M392,280c-9.223,0.023-17.981,4.051-24,11.04c10.667,11.937,10.667,29.983,0,41.92
	c11.607,13.286,31.787,14.648,45.073,3.041c13.286-11.607,14.648-31.787,3.041-45.073C410.035,283.969,401.24,279.983,392,280z"/>
<rect x="336" y="304" style="fill:#C1272D;" width="16" height="16"/>
<rect x="384" y="304" style="fill:#FBB03B;" width="16" height="16"/>
<g>
	<rect x="32" y="304" style="fill:#808080;" width="16" height="16"/>
	<rect x="64" y="304" style="fill:#808080;" width="64" height="16"/>
	<rect x="32" y="336" style="fill:#808080;" width="72" height="16"/>
	<rect x="176" y="304" style="fill:#808080;" width="16" height="16"/>
	<rect x="208" y="304" style="fill:#808080;" width="64" height="16"/>
	<rect x="176" y="336" style="fill:#808080;" width="72" height="16"/>
</g>
<g>
	<path style="fill:#F15A24;" d="M72,160H40v-16h24v-24h16v32C80,156.418,76.418,160,72,160z"/>
	<path style="fill:#F15A24;" d="M136,160h-32c-4.418,0-8-3.582-8-8v-32h16v24h24V160z"/>
</g>
<path style="fill:#0071BC;" d="M464,171.528l-5.056,4.12c-14.64,11.876-31.475,20.754-49.544,26.128
	c10.068-12.479,17.886-26.615,23.104-41.776H464v-16h-26.4c5.587-20.467,8.905-41.487,9.896-62.68
	c-2.411-0.842-4.942-1.288-7.496-1.32h-8.424c-0.972,21.687-4.564,43.176-10.696,64H376V80h-16v64h-44.88
	c-6.135-20.824-9.729-42.313-10.704-64h-16.04v0.4c0.967,21.507,4.329,42.838,10.024,63.6h-50.2
	c-12.794-19.153-20.788-41.105-23.304-64H208.8l0.088,0.8c8.11,78.431,72.348,139.146,151.112,142.824V224h16v-0.344
	c31.843-1.62,62.48-12.694,88-31.808V171.528z M260.584,160h42.904c5.254,15.264,13.15,29.486,23.328,42.016
	C301.266,194.432,278.332,179.884,260.584,160z M360,206.68c-15.288-4.504-29.168-21.6-39.288-46.68H360V206.68z M376,206.68V160
	h39.288C405.168,185.08,391.296,202.176,376,206.68z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
