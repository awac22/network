<?php
/* Smarty version 3.1.40, created on 2022-05-23 07:23:30
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/comment.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_628b36720959c5_44588201',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e01a39822bc2ac4cc06fbd2b85d4918cae74e32d' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/comment.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628b36720959c5_44588201 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<g>
	<g>
		<path d="M448,0H64C28.704,0,0,28.704,0,64v288c0,35.296,28.704,64,64,64h32v80c0,6.208,3.584,11.872,9.216,14.496
			c2.144,0.992,4.48,1.504,6.784,1.504c3.68,0,7.328-1.28,10.24-3.712L232.992,416H448c35.296,0,64-28.704,64-64V64
			C512,28.704,483.296,0,448,0z M480,352c0,17.632-14.368,32-32,32H227.2c-3.744,0-7.36,1.312-10.24,3.712L128,461.856V400
			c0-8.832-7.168-16-16-16H64c-17.632,0-32-14.368-32-32V64c0-17.632,14.368-32,32-32h384c17.632,0,32,14.368,32,32V352z"/>
	</g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
