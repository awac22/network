<?php
/* Smarty version 3.1.40, created on 2022-04-06 17:19:07
  from '/home/anywhereanycity/public_html/network/Script/content/themes/default/images/svg/pages.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_624dcb8bb1e015_40890673',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c0653e88c11d794721e9befdb0c3e527a7eb108b' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/Script/content/themes/default/images/svg/pages.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624dcb8bb1e015_40890673 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Capa_1" enable-background="new 0 0 512 512" height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg"><g><path d="m512 165v-15h-211v302h211v-15c0-37.162-8.647-56.762-16.276-74.055-7.365-16.691-13.724-31.107-13.724-61.945s6.359-45.254 13.724-61.945c7.629-17.293 16.276-36.893 16.276-74.055z" fill="#3b88f5"/><path d="m286 60h-226v302h196l90 45v-287c0-33.084-26.916-60-60-60z" fill="#28abfa"/><path d="m301 362h-45v45c0 24.75 20.25 45 45 45s45-20.25 45-45-20.25-45-45-45z" fill="#3a6fd8"/><path d="m0 0h45v512h-45z" fill="#ff7b2d"/><path d="m45 0h45v512h-45z" fill="#ff5d34"/></g></svg><?php }
}
