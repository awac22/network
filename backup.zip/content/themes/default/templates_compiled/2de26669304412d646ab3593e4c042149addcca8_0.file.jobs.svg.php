<?php
/* Smarty version 3.1.40, created on 2022-04-06 17:19:07
  from '/home/anywhereanycity/public_html/network/Script/content/themes/default/images/svg/jobs.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_624dcb8bb2e982_05625242',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2de26669304412d646ab3593e4c042149addcca8' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/Script/content/themes/default/images/svg/jobs.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624dcb8bb2e982_05625242 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 468.293 468.293" style="enable-background:new 0 0 468.293 468.293;" xml:space="preserve">
<path style="fill:#3B566A;" d="M287.838,22.426h-18.094c-1.702-4.891-6.304-8.424-11.776-8.424h-47.645
	c-5.471,0-10.073,3.533-11.775,8.424h-18.094c-13.775,0-24.976,11.204-24.976,24.975v50.51h157.336v-50.51
	C312.814,33.63,301.613,22.426,287.838,22.426z M287.838,85.422H180.454V47.401h18.095c1.705,4.887,6.306,8.417,11.774,8.417h47.645
	c5.469,0,10.069-3.529,11.774-8.417h18.096V85.422z"/>
<path style="fill:#E56353;" d="M468.293,247.475H0V129.13c0-24.139,19.568-43.707,43.707-43.707h380.878
	c24.139,0,43.707,19.568,43.707,43.707V247.475z"/>
<path style="fill:#D15241;" d="M416.581,454.291H51.712c-20.74,0-37.553-16.813-37.553-37.553l0.775-169.262h439.975l-0.775,169.262
	C454.134,437.477,437.321,454.291,416.581,454.291z"/>
<polygon style="fill:#E1E6E9;" points="265.336,288.265 234.146,325.819 202.956,288.265 202.956,85.423 265.336,85.423 "/>
<polygon style="fill:#3B566A;" points="265.336,205.621 265.336,250.467 202.845,250.467 202.845,205.621 184.072,205.621 
	184.072,269.245 284.115,269.245 284.115,205.621 "/>
<rect x="227.834" y="212.624" style="fill:#64798A;" width="12.488" height="44.438"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
