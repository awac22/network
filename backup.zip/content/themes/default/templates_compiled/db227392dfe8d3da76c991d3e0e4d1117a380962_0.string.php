<?php
/* Smarty version 3.1.40, created on 2022-12-30 06:57:35
  from 'db227392dfe8d3da76c991d3e0e4d1117a380962' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_63ae8bdf95a435_97410672',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63ae8bdf95a435_97410672 (Smarty_Internal_Template $_smarty_tpl) {
?><p>Anywhere Anycity Network</p><?php }
}
