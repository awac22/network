<?php
/* Smarty version 3.1.40, created on 2022-07-01 12:50:48
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/firewall.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62beeda8d38335_90429823',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '00fb907f1c263e54df408c5f729e363dc50be109' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/firewall.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62beeda8d38335_90429823 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Capa_1" enable-background="new 0 0 512 512" height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="256" x2="256" y1="502" y2="10"><stop offset="0" stop-color="#fd5900"/><stop offset="1" stop-color="#ffde00"/></linearGradient><g><g><path d="m497 202h-106.838c.547-4.927.838-9.93.838-15 0-33.254-12.199-65.207-34.349-89.971-.006-.007-73.675-82.051-73.675-82.051-2.906-3.236-7.076-5.046-11.422-4.976-4.349.076-8.451 2.036-11.242 5.371-27.946 33.394-43.723 76.745-41.336 122.808-13.346-12.073-22.083-28.87-24.154-47.749-.646-5.885-4.693-10.84-10.332-12.648s-11.813-.129-15.759 4.284c-5.301 7.961-47.731 40.758-47.731 104.932 0 5.07.291 10.073.838 15h-106.838c-8.284 0-15 6.716-15 15v270c0 8.284 6.716 15 15 15h482c8.284 0 15-6.716 15-15v-270c0-8.284-6.716-15-15-15zm-324.431-78.761c11.076 26.606 32.654 47.658 60.571 57.819 5.199 1.892 11.017.77 15.138-2.921 4.121-3.69 5.876-9.35 4.567-14.725-9.702-39.822-2.384-80.777 20.036-114.774l61.41 68.39c17.223 19.258 26.709 44.107 26.709 69.972 0 57.897-47.103 105-105 105s-105-47.103-105-105c0-23.164 7.609-45.514 21.569-63.761zm158.431 198.761v60h-150v-60zm-301-90h98.722c8.42 23.744 23.304 44.452 42.53 60h-141.252zm0 90h121v60h-121zm211 150h-211v-60h211zm241 0h-211v-60h211zm0-90h-121v-60h121zm0-90h-141.252c19.226-15.548 34.11-36.256 42.53-60h98.722z" fill="url(#SVGID_1_)"/></g></g></svg><?php }
}
