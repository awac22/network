<?php
/* Smarty version 3.1.40, created on 2022-12-08 04:45:14
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/watermark.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_63916bda885b51_79726778',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd1ba3a9427d36eb1eb74d01a14f243342e5614f3' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/watermark.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63916bda885b51_79726778 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Capa_1" enable-background="new 0 0 512 512" height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><linearGradient id="lg1"><stop offset="0" stop-color="#addcff"/><stop offset=".5028" stop-color="#eaf6ff"/><stop offset="1" stop-color="#eaf6ff"/></linearGradient><linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="256" x2="256" xlink:href="#lg1" y1="482" y2="30"/><linearGradient id="lg2"><stop offset="0" stop-color="#5558ff"/><stop offset="1" stop-color="#00c0ff"/></linearGradient><linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="256" x2="256" xlink:href="#lg2" y1="512" y2="0"/><linearGradient id="SVGID_3_" gradientUnits="userSpaceOnUse" x1="256" x2="256" xlink:href="#lg2" y1="364.001" y2="90"/><linearGradient id="SVGID_4_" gradientUnits="userSpaceOnUse" x1="256" x2="256" xlink:href="#lg1" y1="422" y2="181.996"/><g><g><g><path d="m151 30h-76c-8.291 0-15 6.709-15 15s6.709 15 15 15h76c8.291 0 15-6.709 15-15s-6.709-15-15-15zm150 0h-90c-8.291 0-15 6.709-15 15s6.709 15 15 15h90c8.291 0 15-6.709 15-15s-6.709-15-15-15zm60 30h76c8.291 0 15-6.709 15-15s-6.709-15-15-15h-76c-8.291 0-15 6.709-15 15s6.709 15 15 15zm-210 392h-76c-8.291 0-15 6.709-15 15s6.709 15 15 15h76c8.291 0 15-6.709 15-15s-6.709-15-15-15zm150 0h-90c-8.291 0-15 6.709-15 15s6.709 15 15 15h90c8.291 0 15-6.709 15-15s-6.709-15-15-15zm136 0h-76c-8.291 0-15 6.709-15 15s6.709 15 15 15h76c8.291 0 15-6.709 15-15s-6.709-15-15-15zm-377-91c0-8.291-6.709-15-15-15s-15 6.709-15 15v76c0 8.291 6.709 15 15 15s15-6.709 15-15zm-15-45c8.291 0 15-6.709 15-15v-90c0-8.291-6.709-15-15-15s-15 6.709-15 15v90c0 8.291 6.709 15 15 15zm0-150c8.291 0 15-6.709 15-15v-76c0-8.291-6.709-15-15-15s-15 6.709-15 15v76c0 8.291 6.709 15 15 15zm422 180c-8.291 0-15 6.709-15 15v76c0 8.291 6.709 15 15 15s15-6.709 15-15v-76c0-8.291-6.709-15-15-15zm0-150c-8.291 0-15 6.709-15 15v90c0 8.291 6.709 15 15 15s15-6.709 15-15v-90c0-8.291-6.709-15-15-15zm0-136c-8.291 0-15 6.709-15 15v76c0 8.291 6.709 15 15 15s15-6.709 15-15v-76c0-8.291-6.709-15-15-15z" fill="url(#SVGID_1_)"/></g></g><g><g><path d="m45 0c-24.814 0-45 20.186-45 45s20.186 45 45 45 45-20.186 45-45-20.186-45-45-45zm422 90c24.814 0 45-20.186 45-45s-20.186-45-45-45-45 20.186-45 45 20.186 45 45 45zm0 332c-24.814 0-45 20.186-45 45s20.186 45 45 45 45-20.186 45-45-20.186-45-45-45zm-422 0c-24.814 0-45 20.186-45 45s20.186 45 45 45 45-20.186 45-45-20.186-45-45-45z" fill="url(#SVGID_2_)"/></g></g><g><g><path d="m407.003 362c-3.903 0-7.74-1.524-10.609-4.394l-79.394-79.393-79.394 79.394c-5.857 5.858-15.355 5.858-21.213 0l-49.393-49.394-51.394 51.394c-4.29 4.29-10.743 5.573-16.347 3.251-5.605-2.322-9.259-7.791-9.259-13.858v-244c0-8.284 6.716-15 15-15h302c8.284 0 15 6.716 15 15v242c0 6.067-3.654 11.536-9.26 13.858-1.855.769-3.804 1.142-5.737 1.142z" fill="url(#SVGID_3_)"/></g><g><g><path d="m417.606 336.393-90-90c-5.857-5.858-15.355-5.858-21.213 0l-79.393 79.394-49.394-49.394c-5.857-5.858-15.355-5.858-21.213 0l-62 62c-2.813 2.814-4.393 6.629-4.393 10.607v58c0 8.284 6.716 15 15 15h302c8.284 0 15-6.716 15-15v-60c0-3.978-1.58-7.793-4.394-10.607zm-190.602-64.397c24.813 0 45-20.187 45-45s-20.187-45-45-45-45 20.187-45 45 20.186 45 45 45z" fill="url(#SVGID_4_)"/></g></g></g></g></svg><?php }
}
