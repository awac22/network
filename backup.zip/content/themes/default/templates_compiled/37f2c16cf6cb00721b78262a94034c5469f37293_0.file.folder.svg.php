<?php
/* Smarty version 3.1.40, created on 2022-06-05 17:45:42
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/folder.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_629cebc6b72b90_00130865',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '37f2c16cf6cb00721b78262a94034c5469f37293' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/folder.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_629cebc6b72b90_00130865 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 57.912 57.912" style="enable-background:new 0 0 57.912 57.912;" xml:space="preserve">
<g>
	<path style="fill:#B5885B;" d="M54,22.956V7.724c0-0.424-0.344-0.768-0.768-0.768H22.435c-0.27,0-0.52-0.141-0.658-0.373
		l-2.553-4.255c-0.139-0.231-0.389-0.373-0.658-0.373H4.768C4.344,1.956,4,2.3,4,2.724v20.232H54z"/>
</g>
<rect x="7" y="18.956" style="fill:#FFFFFF;" width="44" height="4"/>
<rect x="8" y="15.956" style="fill:#E7ECED;" width="42" height="3"/>
<rect x="9" y="12.956" style="fill:#C7CAC7;" width="40" height="3"/>
<path style="fill:#F7B563;" d="M52.723,55.956H5.189c-0.134,0-0.248-0.098-0.268-0.23L0.003,23.268
	c-0.025-0.164,0.102-0.312,0.268-0.312h57.37c0.166,0,0.293,0.148,0.268,0.312l-4.918,32.458
	C52.971,55.858,52.857,55.956,52.723,55.956z"/>
<rect x="26.956" y="36.956" style="fill:#EDEADA;" width="19" height="12"/>
<g>
	<path style="fill:#CEC9AE;" d="M30.956,41.956h4c0.553,0,1-0.447,1-1s-0.447-1-1-1h-4c-0.553,0-1,0.447-1,1
		S30.403,41.956,30.956,41.956z"/>
	<path style="fill:#CEC9AE;" d="M38.956,41.956h1c0.553,0,1-0.447,1-1s-0.447-1-1-1h-1c-0.553,0-1,0.447-1,1
		S38.403,41.956,38.956,41.956z"/>
	<path style="fill:#CEC9AE;" d="M41.956,43.956h-11c-0.553,0-1,0.447-1,1s0.447,1,1,1h11c0.553,0,1-0.447,1-1
		S42.509,43.956,41.956,43.956z"/>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
