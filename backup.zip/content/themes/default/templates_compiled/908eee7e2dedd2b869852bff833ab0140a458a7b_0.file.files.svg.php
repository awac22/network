<?php
/* Smarty version 3.1.40, created on 2022-12-08 04:45:14
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/files.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_63916bda8a7ed9_22330324',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '908eee7e2dedd2b869852bff833ab0140a458a7b' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/files.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63916bda8a7ed9_22330324 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 58 58" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Page-1" fill="none" fill-rule="evenodd"><g id="003---Folder" fill-rule="nonzero"><path id="Shape" d="m52 14v-2c0-1.6568542-1.3431458-3-3-3h-17c-1.6568542 0-3-1.34314575-3-3-.0049563-3.31165334-2.6883467-5.99504366-6-6h-17c-3.3137085 0-6 2.6862915-6 6v46c0 3.3137085 2.6862915 6 6 6h46c3.3137085 0 6-2.6862915 6-6v-32c0-3.3137085-2.6862915-6-6-6z" fill="#285680"/><path id="Shape" d="m58 20v32c0 3.3137085-2.6862915 6-6 6h-46v-38c0-3.3137085 2.6862915-6 6-6h40c3.3137085 0 6 2.6862915 6 6z" fill="#4482c3"/><g fill="#b0d3f0"><path id="Shape" d="m4 7c-.55228475 0-1-.44771525-1-1 0-1.65685425 1.34314575-3 3-3 .55228475 0 1 .44771525 1 1s-.44771525 1-1 1-1 .44771525-1 1-.44771525 1-1 1z"/><path id="Shape" d="m52 55h-2c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h2c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/><path id="Shape" d="m45 55h-22c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h22c.5522847 0 1 .4477153 1 1s-.4477153 1-1 1z"/></g></g></g></svg><?php }
}
