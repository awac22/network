<?php
/* Smarty version 3.1.40, created on 2022-07-01 12:50:54
  from '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/bank.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62beedae2aa1f2_26195946',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4d3851b1efbe85f26cc6493ce33793bec525085d' => 
    array (
      0 => '/home/anywhereanycity/public_html/network/content/themes/default/images/svg/bank.svg',
      1 => 1638150504,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62beedae2aa1f2_26195946 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 472 472" style="enable-background:new 0 0 472 472;" xml:space="preserve">
<polygon style="fill:#EBE5DD;" points="44,104 236,0 428,104 468,104 468,136 452,136 452,168 20,168 20,136 4,136 4,104 "/>
<rect x="4" y="104" style="fill:#D4C8B8;" width="464" height="16"/>
<polygon style="fill:#E7B900;" points="350.667,104 372,104 236,32 100,104 169.333,104 260,56 "/>
<polygon style="fill:#FFD422;" points="260,56 169.333,104 350.667,104 "/>
<rect x="20" y="408" style="fill:#EBE5DD;" width="432" height="32"/>
<g>
	<rect x="20" y="136" style="fill:#D4C8B8;" width="432" height="16"/>
	<rect x="20" y="424" style="fill:#D4C8B8;" width="432" height="16"/>
</g>
<rect x="4" y="440" style="fill:#EBE5DD;" width="464" height="32"/>
<rect x="4" y="456" style="fill:#D4C8B8;" width="464" height="16"/>
<rect x="396" y="200" style="fill:#5EAC24;" width="24" height="176"/>
<rect x="420" y="200" style="fill:#69C229;" width="16" height="176"/>
<polygon style="fill:#47821B;" points="308,200 308,224 308,352 308,376 332,376 332,200 "/>
<g>
	<rect x="332" y="200" style="fill:#5EAC24;" width="16" height="176"/>
	<rect x="52" y="200" style="fill:#5EAC24;" width="24" height="176"/>
</g>
<rect x="36" y="200" style="fill:#69C229;" width="16" height="176"/>
<polygon style="fill:#47821B;" points="164,200 164,224 164,352 164,376 140,376 140,200 "/>
<rect x="124" y="200" style="fill:#5EAC24;" width="16" height="176"/>
<circle style="fill:#FFD422;" cx="236" cy="288" r="64"/>
<g>
	<path style="fill:#FFFFFF;" d="M201.715,258.906l-11.438-11.188c12.152-12.418,28.391-19.258,45.723-19.258v16
		C223.008,244.461,210.832,249.59,201.715,258.906z"/>
	<path style="fill:#FFFFFF;" d="M261.004,351.363l-6.25-14.727c11.957-5.078,21.164-14.559,25.914-26.695l14.898,5.836
		C289.234,331.953,276.957,344.59,261.004,351.363z"/>
</g>
<g>
	<path style="fill:#E7B900;" d="M236,208c-44.113,0-80,35.887-80,80s35.887,80,80,80s80-35.887,80-80S280.113,208,236,208z M236,352
		c-35.289,0-64-28.711-64-64s28.711-64,64-64s64,28.711,64,64S271.289,352,236,352z"/>
	<path style="fill:#E7B900;" d="M260,304c0-13.234-10.766-24-24-24c-4.41,0-8-3.59-8-8s3.59-8,8-8h16v-16h-8v-8h-16v9.474
		c-9.292,3.313-16,12.11-16,22.526c0,13.234,10.766,24,24,24c4.41,0,8,3.59,8,8s-3.59,8-8,8h-16v16h8v8h16v-9.474
		C253.292,323.213,260,314.416,260,304z"/>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
